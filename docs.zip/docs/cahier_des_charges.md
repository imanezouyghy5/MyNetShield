# Cahier des Charges – MyNetShield
1. Présentation du Projet
**Titre**: MyNetShield : Plateforme locale intelligente de surveillance, d’analyse et de contrôle de la sécurité des réseaux domestiques.
**Contexte** : Augmentation des objets connectés (IoT) dans les foyers marocains et manque de solutions de sécurité accessibles aux non-experts.
**Objectif Général** : Développer une application locale permettant de scanner, surveiller et sécuriser un réseau domestique via une interface simple et une IA locale.
2. Objectifs Spécifiques
**Scanner et cartographier son réseau local**  
   → Afficher la liste des appareils connectés avec leurs adresses IP, MAC, et type (PC, smartphone, IoT, etc.).
**Évaluer le niveau global de sécurité**  
   → Calculer un **score de sécurité** (ex. : 78/100) accompagné de recommandations claires et personnalisées.
**Détecter les comportements anormaux**  
   → Utiliser un modèle de **machine learning non supervisé** (Isolation Forest) pour identifier les activités suspectes (ex. : communication nocturne vers un pays étranger).
**Interagir via une IA conversationnelle locale**  
   → Poser des questions en langage naturel en **français** (ex. : *« Est-ce que cette caméra est dangereuse ? »*) et recevoir des réponses exploitables  
**Contrôler le réseau par commande vocale ou textuelle**  
   → Exécuter des actions sécurisées comme *« Bloque l’appareil 192.168.1.20 »*, avec confirmation obligatoire.
**Générer des rapports exploitables**  
   → Exporter un résumé de la sécurité du réseau au format **PDF ou HTML**, lisible par un particulier ou une petite PME. 
3. Les Acteurs (Utilisateurs)
 *Utilisateur Principal* : Administrateur du réseau (Parent, particulier, PME).
 *Profil* : Utilisateur pouvant avoir des compétences techniques limitées.
 *Besoin*: Voir qui est connecté, savoir si c'est dangereux, et pouvoir couper l'accès facilement.
 *Système* : L'application MyNetShield (Backend Python + Frontend Web).
4. Contraintes
   ### Fonctionnelles
     - Interface principale en **français** (extensible à l’arabe et à l’anglais).
     - Public cible : **non-techniciens** (parents, seniors, petites entreprises).
     - Toutes les données restent **strictement locales** (*privacy by design*).
     - Aucune dépendance à Internet après l’installation.
   ### Techniques
     - **Backend** : Python (pour sa richesse en bibliothèques réseau et IA).
     - **IA/ML** : Ollama (modèles Phi-3 ou Mistral), apprentissage non supervisé  
     - **Frontend** : HTML5, CSS3, JavaScript (Vanilla)
     - **Sécurité** : Pare-feu local (Windows Firewall / iptables), chiffrement local des logs  
     - **Interface** : application web légère (HTML/CSS/JS) ou interface graphique simple.
     - **Analyse réseau** : utilisation du protocole ARP pour la découverte des appareils.
     - **Détection d’anomalies** : algorithme Isolation Forest (apprentissage non supervisé).
     - **Déploiement** : Exécutable Windows (via PyInstaller), option Raspberry Pi 
    ### Sécurité
       - Toute action critique (blocage, isolement) nécessite une **confirmation explicite**.
       - L’IA ne peut pas exécuter d’actions sans validation humaine.
5. Livrables Attendus
 - Dossier de conception (UML + cahier des charges)
 - Prototype fonctionnel de scan réseau (Jalon 2)
 - Application complète avec IA et détection d’anomalies (Jalon 3)
 - Rapport final de PFE + code source + support de présentation
6. Innovation et Valeur Ajoutée
 - **Première application marocaine** combinant IA locale, sécurité réseau et contrôle conversationnel.
 - **Approche pédagogique** : utilisable dans les établissements scolaires pour sensibiliser à la cybersécurité.
 - **Respect total de la vie privée** : aucune donnée ne quitte le réseau de l’utilisateur.
 - **Accessibilité** : conçue pour les citoyens ordinaires, pas seulement les experts IT.