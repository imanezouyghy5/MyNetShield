# État de l’Art – MyNetShield
## 1. Outils existants de surveillance réseau
Plusieurs outils de scan et d’analyse réseau sont aujourd’hui disponibles, mais ils présentent des limites majeures pour les utilisateurs non techniques :
- **Wireshark** :  
  Permet une analyse approfondie du trafic réseau en temps réel. Cependant, son interface complexe, ses logs illisibles et sa dépendance à la compréhension des protocoles TCP/IP en font un outil réservé aux experts en cybersécurité.
- **Nmap** :  
  Outil puissant en ligne de commande pour découvrir les hôtes et les ports ouverts. Très efficace, mais inaccessible sans formation technique. De plus, il ne propose ni interface graphique intuitive ni actions correctives.
- **Fing (application mobile)** :  
  Offre une interface simple et conviviale, mais repose sur des services cloud centralisés. Les données réseau (adresses MAC, types d’appareils) sont envoyées à des serveurs externes, posant de sérieux **problèmes de vie privée**.
- **Angry IP Scanner** :  
  Gratuit et léger, mais purement passif : il liste les IP actives sans analyser les risques ni proposer de mesures de sécurité.
 **Conclusion** : Aucun outil ne combine **simplicité**, **localité** et **capacité d’action proactive** — ce qui justifie la création de **MyNetShield**.
## 2. Protocoles réseau pour la découverte locale
La cartographie d’un réseau local repose sur des protocoles fondamentaux :
- **ARP (Address Resolution Protocol)** :  
  Utilisé pour associer une adresse IP à une adresse MAC sur le même segment réseau (LAN). Il permet d’interroger la table ARP du routeur ou d’envoyer des requêtes broadcast (`who-has`) pour découvrir tous les appareils connectés. C’est la méthode la plus fiable et rapide pour un scan passif, car elle fonctionne même si un appareil bloque les pings.
- **ICMP (Internet Control Message Protocol)** :  
  Le protocole derrière la commande `ping`. Il permet de tester la connectivité avec un hôte, mais de nombreux appareils IoT (caméras, capteurs) désactivent ICMP par défaut → faux négatifs possibles.
Dans **MyNetShield**, le **scan ARP** sera la méthode principale (via la bibliothèque Python **Scapy**), complétée éventuellement par du ping pour validation.
## 3. Intelligence artificielle locale et détection d’anomalies
### IA conversationnelle hors ligne
- **Ollama** est une plateforme open-source permettant d’exécuter des modèles de langage localement, sans connexion internet.
- Les modèles **Phi-3** (Microsoft) et **Mistral** (Mistral AI) sont particulièrement adaptés :
  - Légers (2–4 Go de RAM),
  - Rapides sur CPU standard,
  - Capables de comprendre et générer du **français**,
  - Respectueux de la vie privée (**aucune donnée ne quitte la machine**).
Ces caractéristiques en font le choix idéal pour un assistant de sécurité intégré à MyNetShield.
### Détection d’anomalies sans supervision
- Dans un réseau domestique, il est impossible d’avoir des « labels » (normal/anormal) pour chaque appareil → apprentissage **non supervisé**.
- **Isolation Forest** est un algorithme de détection d’anomalies particulièrement efficace :
  - Il isole les points atypiques en construisant des arbres aléatoires.
  - Très performant sur des données faiblement dimensionnelles (ex. : volume de trafic, fréquence de connexions, ports utilisés).
  - Implémenté dans **Scikit-learn**, compatible avec Python.
Ce modèle permettra à MyNetShield de détecter des comportements suspects (ex. : une imprimante qui communique vers la Chine à 3h du matin) sans intervention humaine.
## 4. Synthèse et justification du projet
|        Besoin identifié      | Solution existante | Lacune                  | Réponse de MyNetShield |
|------------------------------|--------------------|-------------------------|------------------------|
| Voir les appareils connectés | Nmap, Fing         | Trop technique ou cloud | Scan ARP local + dashboard simple |
| Comprendre les risques       | Wireshark          | Inaccessible  | Score de sécurité + conseils clairs |
| Poser des questions          | Aucun outil grand public | Absence d’IA | Chat IA locale en français (Ollama) |
| Agir face à une menace       | Pare-feu manuel    | Complexe | Commandes naturelles sécurisées |
| Preuve de vigilance          | Rapports manuels   | Fastidieux | Génération automatique PDF/HTML |
Ainsi, *MyNetShield comble un vide technologique et pédagogique* au Maroc, en offrant une solution *locale, intelligente, proactive et accessible* aux foyers comme aux PME.