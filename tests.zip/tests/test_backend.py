import pytest
import time
from app.dashboard import create_app
from app.ml.ml_anomaly import MLAnomalyDetector

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_api_stats(client):
    """Test the /api/stats endpoint"""
    response = client.get('/api/stats')
    assert response.status_code == 200
    data = response.get_json()
    assert "online_count" in data
    assert "offline_count" in data
    assert "total_count" in data
    assert "ml_status" in data

def test_api_devices(client):
    """Test the /api/devices endpoint"""
    response = client.get('/api/devices')
    assert response.status_code == 200
    data = response.get_json()
    assert "devices" in data
    assert "total" in data
    assert isinstance(data["devices"], list)

def test_scan_start(client):
    """Test the /api/scan/start endpoint"""
    response = client.post('/api/scan/start')
    # Can be 200 or 429 if already running
    assert response.status_code in [200, 429]
    if response.status_code == 200:
        data = response.get_json()
        assert data["status"] == "started"

def test_ml_anomaly_schema():
    """Test that MLAnomalyDetector sets 'is_anomaly' at the root dictionary level"""
    detector = MLAnomalyDetector()
    # Mock data preprocessor
    class MockPreprocessor:
        feature_columns = ["f1"]
        def extract_features_from_device(self, d):
            return [0.0]

    devices = [{"ip": "192.168.1.1", "mac": "00:11:22:33:44:55", "open_ports": []}]
    results = detector.detect_anomalies(devices, MockPreprocessor())
    
    assert len(results) == 1
    # Check that is_anomaly is at the root
    assert "is_anomaly" in results[0]
    assert "anomaly_reason" in results[0]
