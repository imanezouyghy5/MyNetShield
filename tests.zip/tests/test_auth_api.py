import requests
import sys
import os

BASE_URL = "http://127.0.0.1:5000/api/auth"
TEST_EMAIL = "test_user@mynetshield.local"
TEST_PASSWORD = "Password123!"
TEST_NAME = "Test User"

def test_auth():
    print("Testing MyNetShield Authentication...")
    
    # 1. Register User
    print(f"\n1. Registering user: {TEST_EMAIL}...")
    try:
        register_payload = {
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD,
            "name": TEST_NAME
        }
        resp = requests.post(f"{BASE_URL}/register", json=register_payload)
        print(f"   Status: {resp.status_code}")
        print(f"   Response: {resp.json()}")
        
        if resp.status_code not in [200, 409]:
            print("❌ Registration failed with unexpected status.")
            return False
            
    except Exception as e:
        print(f"❌ Error during registration request: {e}")
        return False

    # 2. Login User
    print(f"\n2. Logging in with: {TEST_EMAIL}...")
    try:
        login_payload = {
            "email": TEST_EMAIL,
            "password": TEST_PASSWORD
        }
        resp = requests.post(f"{BASE_URL}/login", json=login_payload)
        print(f"   Status: {resp.status_code}")
        print(f"   Response: {resp.json()}")
        
        if resp.status_code == 200 and resp.json().get('success'):
            print("✅ Login Successful!")
            user_data = resp.json().get('user')
            if user_data.get('email') == TEST_EMAIL.lower():
                print("✅ User data verified.")
            else:
                print("❌ User data mismatch.")
                return False
        else:
            print("❌ Login failed.")
            return False
            
    except Exception as e:
        print(f"❌ Error during login request: {e}")
        return False

    # 3. Test Invalid Login
    print("\n3. Testing invalid login...")
    try:
        invalid_payload = {
            "email": TEST_EMAIL,
            "password": "WrongPassword"
        }
        resp = requests.post(f"{BASE_URL}/login", json=invalid_payload)
        print(f"   Status: {resp.status_code}")
        if resp.status_code == 401:
            print("✅ Successfully rejected invalid password.")
        else:
            print("❌ Failed to reject invalid password.")
            return False
    except Exception as e:
        print(f"❌ Error during invalid login test: {e}")
        return False

    print("\n🎉 All authentication tests passed!")
    return True

if __name__ == "__main__":
    if not test_auth():
        sys.exit(1)
