import requests
import time
import sys

BASE_URL = "http://localhost:5000/api"

def test_api():
    print("--- 1. Testing /api/stats ---")
    try:
        r = requests.get(f"{BASE_URL}/stats")
        print(f"Status: {r.status_code}")
        print(f"Data: {r.json()}")
    except Exception as e:
        print(f"Error: {e}")

    print("\n--- 2. Testing /api/scan/start ---")
    try:
        r = requests.post(f"{BASE_URL}/scan/start")
        print(f"Status: {r.status_code}")
        print(f"Data: {r.json()}")
    except Exception as e:
        print(f"Error: {e}")

    print("\n--- 3. Polling /api/scan/status ---")
    start_time = time.time()
    while time.time() - start_time < 60: # Max 60s
        try:
            r = requests.get(f"{BASE_URL}/scan/status")
            status = r.json()
            message = status['message'].encode('ascii', 'ignore').decode('ascii')
            print(f"Running: {status['running']}, Progress: {status['progress']}, Message: {message}")
            if not status['running'] and status['progress'] == 100:
                print("✅ Scan Complete!")
                break
            if not status['running'] and status['error']:
                print(f"❌ Scan failed: {status['error']}")
                break
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(2)

    print("\n--- 4. Testing /api/devices ---")
    try:
        r = requests.get(f"{BASE_URL}/devices")
        data = r.json()
        print(f"Total devices: {data['total']}")
        if data['devices']:
            dev = data['devices'][0]
            print(f"First device sample: {dev['ip']} - {dev.get('hostname')} - ML Anomaly: {dev.get('is_anomaly')}")
            if 'is_anomaly' in dev:
                print("✅ JSON Schema for ML Anomaly matches!")
            else:
                print("❌ JSON Schema for ML Anomaly DOES NOT match!")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_api()
